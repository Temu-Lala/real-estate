:HL["/_next/static/chunks/0gyoswazsvwuk.css","style"]
:HL["/_next/static/media/07c7676b89ed2778-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"properties","h":96,"c":"$Q2"}]]
0:{"b":"dZA04pR3ufyPk4Wl6UwdW","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
