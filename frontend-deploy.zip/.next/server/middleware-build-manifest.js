globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/dZA04pR3ufyPk4Wl6UwdW/_buildManifest.js",
    "static/dZA04pR3ufyPk4Wl6UwdW/_ssgManifest.js",
    "static/dZA04pR3ufyPk4Wl6UwdW/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2cfjb_e_b7yc0.js",
    "static/chunks/1lu0ax-gba8ew.js",
    "static/chunks/105a5qyebhf5_.js",
    "static/chunks/229w6vybyllny.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/analytics/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/leads/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/media/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/admin/properties/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/properties/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    },
    "/properties/[slug]/page": {
      "otherChunks": [
        "static/chunks/2cfjb_e_b7yc0.js",
        "static/chunks/1lu0ax-gba8ew.js",
        "static/chunks/105a5qyebhf5_.js",
        "static/chunks/229w6vybyllny.js"
      ],
      "runtimeModuleIds": [
        18824
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
