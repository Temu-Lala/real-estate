module.exports=[30487,a=>{"use strict";let b=(0,a.i(64588).f)("arrow-up-right",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);a.s(["f",0,b])}];

//# sourceMappingURL=1z_g_lucide-react_dist_esm_icons_arrow-up-right_mjs_0vdlxtlrqphy0._.js.map