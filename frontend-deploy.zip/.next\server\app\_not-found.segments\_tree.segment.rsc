:HL["/_next/static/chunks/0gyoswazsvwuk.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"_IfA_Yu-DsOniyBEBW6A4","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
