var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/track/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__18d1dge_19cwf._.js")
R.c("server/chunks/_next-internal_server_app_api_track_route_actions_0eauih4b26051.js")
R.m(54485)
module.exports=R.m(54485).exports
