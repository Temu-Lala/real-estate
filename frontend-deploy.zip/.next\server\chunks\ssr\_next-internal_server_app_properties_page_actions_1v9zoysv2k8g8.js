module.exports=[80021,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_properties_page_actions_1v9zoysv2k8g8.js.map