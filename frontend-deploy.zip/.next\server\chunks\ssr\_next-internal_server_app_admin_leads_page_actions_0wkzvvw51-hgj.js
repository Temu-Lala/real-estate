module.exports=[38420,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_leads_page_actions_0wkzvvw51-hgj.js.map